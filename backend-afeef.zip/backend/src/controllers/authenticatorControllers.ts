import { Request, Response } from "express";
import { UsersService } from "../services/user.service";

export class AuthControllers {
  public static async login(req: Request, res: Response){
    const args = req.body;
    const user = await UsersService.login(args);
    res.send(user);
  };
public static async register(req: Request, res: Response) {
    const args = req.body;
    const user = await UsersService.register(args);
    res.send(user);
};
public static async getuser(req: Request, res: Response){
    const args = req.body;
    const items = await UsersService.getUser(args);
    res.send(items);
}

};