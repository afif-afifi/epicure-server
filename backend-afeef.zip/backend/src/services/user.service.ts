import { UserDal } from "../dal/user.dal";
import bcrypt from "bcrypt";

export class UsersService {

    public static async login(args: any) {
        const hashedPasswordFromDB = await UserDal.getUserPassword(args);
        if(!hashedPasswordFromDB){
            return {status: "failure", message: "Incorrect username or password"};
        }
        const response = await bcrypt.compare(args.password, hashedPasswordFromDB);
        if(response){
            return {status: "success", message: "Welcome!"};
        }
        return {status: "failure", message: "Incorrect username or password"};
    };

    public static async register(user: any) {
        const saltRounds = 10;
        const isUserExist = await UserDal.CompareEmails(user);
        if(isUserExist){
            return {status: "failure", message: "User already exists"};
        }
        bcrypt.hash(user.password, saltRounds, async function (err, hash) {
            user["password"] = hash;
            const res = await UserDal.createUser(user);
            return res;
        });
    };
    public static async getUser(args:any){
        const res = UserDal.getUser(args);
        return res;
    };
};