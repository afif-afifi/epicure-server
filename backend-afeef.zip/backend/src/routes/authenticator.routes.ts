import { Router } from "express"; 
import {AuthControllers} from "../controllers/authenticatorControllers";

const router = Router();
router.post("/login", AuthControllers.login);
router.post("/register", AuthControllers.register);
router.post("/getuser", AuthControllers.getuser);

export default router;