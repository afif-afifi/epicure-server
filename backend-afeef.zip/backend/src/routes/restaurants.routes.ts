import { Router } from "express";
import { RestaurantsController } from "../controllers/restaurantsControllers";

const router = Router();

router.get("/getRestaurants", RestaurantsController.getRestaurants);
router.post("/createRestaurant", RestaurantsController.createRestaurant);

export default router;
