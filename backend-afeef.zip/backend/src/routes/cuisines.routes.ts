import { Router } from "express";
import { cuisinesController } from "../controllers/cuisinesControllers";
const router = Router();
router.get("/getCuisines", cuisinesController.getCuisines);
router.post("/createCuisines", cuisinesController.createCuisines);
export default router;