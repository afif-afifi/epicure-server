import { Router } from "express";
import { ChefsController } from "../controllers/chefsControllers";
const router = Router();
router.get("/getChefs", ChefsController.getChefs);
router.post("/createChef", ChefsController.createChef);
export default router;