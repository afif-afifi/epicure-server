import express from 'express';
import chefsRoutes from './chefs.routes';
import cuisinesRoutes from './cuisines.routes';
import restaurantsRoutes from './restaurants.routes';
import dishesRoutes from './dishes.routes';
import authenticatorRoutes from './authenticator.routes'; 

const router = express.Router();
router.use('/api/auth',authenticatorRoutes);
router.use('/api/chefs/', chefsRoutes);
router.use('/api/cuisines/', cuisinesRoutes);
router.use('/api/restaurants/', restaurantsRoutes);
router.use('/api/dishes/', dishesRoutes);
export default router;